smooth <-
function(){
  print("The function is smooth the time series !");
}
