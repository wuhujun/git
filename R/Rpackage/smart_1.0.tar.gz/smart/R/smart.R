smart <-
function(){
  print("This is a test of make a R package !");
}
